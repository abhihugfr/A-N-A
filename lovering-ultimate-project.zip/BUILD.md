# Build and Firebase setup

## Build (Java 17 + Android SDK 34 required)
1. Install Android Studio, or the command-line SDK, and set `ANDROID_HOME`.
2. `./gradlew assembleDebug` (first run downloads `gradle-wrapper.jar`, then Gradle 8.9).
   APK: `app/build/outputs/apk/debug/app-debug.apk`. Install: `adb install -r <apk>`.
   Without `app/google-services.json` the app still builds; account features show as unavailable.

## Firebase
1. console.firebase.google.com > Add project.
2. Add Android app, package name `com.lovering.app`. Download `google-services.json` into `app/`.
   For debug sign-in features later, add your debug SHA-1 (`./gradlew signingReport`).
3. Build > Authentication > Get started > enable Email/Password.
4. Build > Firestore Database > Create database (production mode).
5. Upgrade to the Blaze plan (needed for Cloud Functions and scheduled functions).
6. `npm i -g firebase-tools && firebase login && firebase use --add`
7. `cd functions && npm install && cd ..`
8. `firebase deploy --only firestore:rules,firestore:indexes,functions`
9. Cloud Messaging is enabled by default; nothing in the app uses it yet.

## Not implemented (do not treat as working)
- Pairing (QR or code): no `createPair` function or UI exists, so `pairs/*` documents are never created and
  `ConsentStore`, `requestSession`, `respondSession`, `endSession` and `unpair` have nothing to act on.
- Consent UI, partner dashboard, shared-data publishing, schedule/pause for sharing.
- WebRTC signaling and streaming. `ScreenShareService` only holds the MediaProjection and shows the
  notification/timeout; it sends no video. No WebRTC dependency is included.
- Location reading and sharing (only the permission request exists), background location.
- Ring partner / find my phone, FCM receiver and token upload, QR scanning.
- Account deletion in the app (the `deleteAccount` function exists server-side only).
- Wi-Fi SSID, per-app permission audit, app diagnostics.
- The scheduled/callable functions and rules were never deployed or tested.
