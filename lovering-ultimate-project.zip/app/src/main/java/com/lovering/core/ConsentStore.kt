package com.lovering.core

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/** Owner-controlled consent flags. Preferences only: they NEVER substitute for Android runtime permissions. */
data class Consent(
    val batteryShared: Boolean = false,
    val storageShared: Boolean = false,
    val networkShared: Boolean = false,
    val deviceInfoShared: Boolean = false,
    val locationAllowed: Boolean = false,
    val backgroundLocationAllowed: Boolean = false,
    val screenAllowed: Boolean = false,   // partner may *request*; owner still approves every session
    val ringAllowed: Boolean = true,
)

class ConsentStore(private val pairId: String) {
    private val uid get() = FirebaseAuth.getInstance().currentUser!!.uid
    private val doc get() = FirebaseFirestore.getInstance().document("pairs/$pairId/consent/$uid")

    fun save(c: Consent) = doc.set(c)
    fun revokeAll() = doc.set(Consent(ringAllowed = false))
    fun set(field: String, value: Boolean) = doc.update(field, value)
}
