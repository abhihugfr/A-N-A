package com.lovering.core

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Every session, no exceptions:
 * 1. Partner calls requestSession("screen") -> owner gets FCM.
 * 2. Owner taps Approve -> respondSession(approve=true).
 * 3. Activity launches MediaProjectionManager.createScreenCaptureIntent() (Android's own dialog).
 * 4. Result is passed here once, held in memory only, never persisted or reused.
 * 5. Ongoing notification with Stop; system status-bar indicator stays visible.
 */
class ScreenShareService : Service() {
    private var projection: MediaProjection? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val code = i?.getIntExtra("code", 0) ?: 0
        val data = i?.getParcelableExtra<Intent>("data")
        val timeoutMs = i?.getLongExtra("timeoutMs", 30 * 60_000L) ?: 30 * 60_000L
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        startForeground(1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).apply {
            registerCallback(object : MediaProjection.Callback() {
                override fun onStop() = stopSelf()   // user stopped via system UI
            }, handler)
        }
        // TODO: feed `projection` to WebRTC ScreenCapturerAndroid; adapt maxBitrateBps /
        // resolution from getStats() RTT + packet loss.
        handler.postDelayed({ stopSelf() }, timeoutMs)   // automatic timeout
        return START_NOT_STICKY   // never auto-restart: a restart would lack fresh consent
    }

    private fun notification(): Notification {
        val ch = "share"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Screen sharing", NotificationManager.IMPORTANCE_HIGH))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, ScreenShareService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, ch).setContentTitle("Sharing your screen with your partner")
            .setSmallIcon(android.R.drawable.ic_menu_share).setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
    }

    override fun onDestroy() { projection?.stop(); projection = null; handler.removeCallbacksAndMessages(null) }
    override fun onBind(p0: Intent?): IBinder? = null
}
