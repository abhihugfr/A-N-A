package com.lovering

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.lovering.core.DeviceInfo
import com.lovering.core.ScreenShareService

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private var phoneText = ""

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { render() }

    // Android's own MediaProjection consent dialog. Asked fresh on every use; result is never stored.
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScreenShareService::class.java)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", data)
                    .putExtra("timeoutMs", 60_000L)
                ContextCompat.startForegroundService(this, i)
                toast("Capture permission granted for 60 s (no streaming yet)")
            } else {
                toast("Screen capture was not approved")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply { addView(content) })
        render()
    }

    private fun render() {
        content.removeAllViews()
        header("LoveRing (early build)")
        body("Only the items below work. Pairing, partner dashboard, location sharing, WebRTC, ring and find-phone are NOT implemented yet.")

        header("Account")
        accountSection()

        header("My phone")
        button("Check my phone") { phoneText = DeviceInfo.snapshot(this).entries.joinToString("\n") { "${it.key}: ${it.value}" }; render() }
        if (phoneText.isNotEmpty()) body(phoneText)

        header("Permission center")
        body(permissionStatus())
        button("Request location and notification permissions") {
            val list = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(list.toTypedArray())
        }

        header("Screen capture consent test")
        body("Shows Android's capture dialog and starts the notification service for 60 s. It does not stream or record anything.")
        button("Test screen capture consent") {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }

    private fun accountSection() {
        if (FirebaseApp.getApps(this).isEmpty()) {
            body("Firebase is not configured (app/google-services.json missing). Account features are unavailable.")
            return
        }
        val auth = FirebaseAuth.getInstance()
        val user = auth.currentUser
        if (user == null) {
            val email = field("Email", false)
            val pw = field("Password (min 6 characters)", true)
            button("Register") {
                auth.createUserWithEmailAndPassword(email.text.toString().trim(), pw.text.toString())
                    .addOnCompleteListener { t ->
                        if (t.isSuccessful) {
                            t.result.user?.sendEmailVerification()
                            toast("Account created. Verification email sent.")
                        } else toast(t.exception?.message)
                        render()
                    }
            }
            button("Sign in") {
                auth.signInWithEmailAndPassword(email.text.toString().trim(), pw.text.toString())
                    .addOnCompleteListener { t ->
                        if (!t.isSuccessful) toast(t.exception?.message)
                        render()
                    }
            }
        } else {
            body("Signed in as ${user.email}\nEmail verified: ${user.isEmailVerified}")
            button("Refresh verification status") { user.reload().addOnCompleteListener { render() } }
            button("Resend verification email") {
                user.sendEmailVerification().addOnCompleteListener { toast(if (it.isSuccessful) "Sent" else it.exception?.message) }
            }
            button("Sign out") { auth.signOut(); render() }
        }
    }

    private fun permissionStatus(): String {
        fun s(p: String) = if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED) "granted" else "not granted"
        val notif = if (Build.VERSION.SDK_INT >= 33) s(Manifest.permission.POST_NOTIFICATIONS) else "not required"
        return "Fine location: ${s(Manifest.permission.ACCESS_FINE_LOCATION)}\n" +
            "Coarse location: ${s(Manifest.permission.ACCESS_COARSE_LOCATION)}\n" +
            "Notifications: $notif"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String?) = Toast.makeText(this, m ?: "Error", Toast.LENGTH_LONG).show()
    private fun header(t: String) = content.addView(TextView(this).apply { text = t; textSize = 20f; setPadding(0, dp(20), 0, dp(4)) })
    private fun body(t: String) = content.addView(TextView(this).apply { text = t; setPadding(0, dp(4), 0, dp(4)) })
    private fun button(t: String, onClick: () -> Unit) = content.addView(Button(this).apply { text = t; setOnClickListener { onClick() } })
    private fun field(hint: String, password: Boolean): EditText = EditText(this).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_TEXT or
            if (password) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        content.addView(this)
    }
}
