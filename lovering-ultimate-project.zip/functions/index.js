const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

const FEATURES = ["screen", "location", "ring"];
const TTL_MS = { screen: 30 * 60e3, location: 60 * 60e3, ring: 60e3 };

async function pairOf(uid) {
  const q = await db.collection("pairs").where("members", "array-contains", uid).limit(1).get();
  if (q.empty) throw new HttpsError("failed-precondition", "Not paired");
  const d = q.docs[0];
  return { id: d.id, partner: d.data().members.find(m => m !== uid) };
}

// Creates a pending request + FCM. Never grants anything by itself.
exports.requestSession = onCall(async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "Sign in");
  const { feature } = req.data;
  if (!FEATURES.includes(feature)) throw new HttpsError("invalid-argument", "feature");
  const p = await pairOf(req.auth.uid);
  const consent = await db.doc(`pairs/${p.id}/consent/${p.partner}`).get();
  if (!consent.exists || consent.data()[feature + "Allowed"] !== true)
    throw new HttpsError("permission-denied", "Partner has not enabled this feature");
  const ref = await db.collection(`pairs/${p.id}/sessions`).add({
    feature, requester: req.auth.uid, target: p.partner, status: "pending",
    createdAt: Date.now(), expiresAt: Date.now() + TTL_MS[feature],
  });
  const tok = (await db.doc(`users/${p.partner}`).get()).data()?.fcmToken;
  if (tok) await admin.messaging().send({ token: tok, data: { type: "session_request", sid: ref.id, feature }, android: { priority: "high" } });
  return { sid: ref.id };
});

// Only the TARGET can approve/deny. Approval still triggers Android's own prompt on the device.
exports.respondSession = onCall(async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "Sign in");
  const { pairId, sid, approve } = req.data;
  const ref = db.doc(`pairs/${pairId}/sessions/${sid}`);
  const s = (await ref.get()).data();
  if (!s || s.target !== req.auth.uid) throw new HttpsError("permission-denied", "Not your request");
  if (s.status !== "pending" || Date.now() > s.expiresAt) throw new HttpsError("failed-precondition", "Expired");
  await ref.update({ status: approve ? "approved" : "denied", respondedAt: Date.now() });
  return { ok: true };
});

// Either side can end instantly.
exports.endSession = onCall(async (req) => {
  const { pairId, sid } = req.data;
  const ref = db.doc(`pairs/${pairId}/sessions/${sid}`);
  const s = (await ref.get()).data();
  if (!s || ![s.requester, s.target].includes(req.auth?.uid)) throw new HttpsError("permission-denied", "no");
  await ref.update({ status: "ended", endedAt: Date.now() });
  return { ok: true };
});

exports.unpair = onCall(async (req) => {
  const p = await pairOf(req.auth.uid);
  await db.recursiveDelete(db.doc(`pairs/${p.id}`));
  return { ok: true };
});

exports.deleteAccount = onCall(async (req) => {
  const uid = req.auth.uid;
  try { const p = await pairOf(uid); await db.recursiveDelete(db.doc(`pairs/${p.id}`)); } catch (_) {}
  await db.recursiveDelete(db.doc(`users/${uid}`));
  await admin.auth().deleteUser(uid);
  return { ok: true };
});

exports.expireSessions = onSchedule("every 5 minutes", async () => {
  const q = await db.collectionGroup("sessions").where("expiresAt", "<", Date.now())
    .where("status", "in", ["pending", "approved"]).get();
  await Promise.all(q.docs.map(d => d.ref.update({ status: "expired" })));
});
