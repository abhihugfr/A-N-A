# LoveRing Ultimate – starter modules

These files are drop-in modules for your existing LoveRing project. I could not see your current
code, run Gradle, or test on devices, so **nothing here is built or device-tested yet**.

## Included
- `firestore.rules` – owner-only writes; partner reads only categories the owner enabled
- `functions/index.js` – requestSession, respondSession, endSession, unpair, deleteAccount, expireSessions
- `ConsentStore.kt`, `DeviceInfo.kt`, `ScreenShareService.kt`, manifest snippet

## Still to build in the app (not included)
Email verification + QR pairing UI, permission dashboard, MY/PARTNER dashboards, WebRTC signaling
(offers/ICE via a `sessions/{sid}/signal` subcollection) + capturer, location service/schedule,
ring/find-phone (FCM data message -> full-screen notification + alarm stream), FCM receiver.

## Setup
1. Firebase console: create project, add Android app (package name), enable Email/Password auth, Firestore, FCM.
2. Put `google-services.json` in `app/`.
3. `npm i -g firebase-tools && firebase login && firebase init` (Firestore, Functions) then
   `firebase deploy --only firestore:rules,functions` (Functions needs Blaze plan).
4. Gradle: firebase-bom, firebase-auth/firestore/messaging/functions, `io.getstream:stream-webrtc-android`, ML Kit barcode or ZXing.
5. Build: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`; install with `adb install`.

## Persistent consent vs fresh Android authorization
| Feature | After one-time setup | Needs fresh authorization |
|---|---|---|
| Battery, storage, network, model, Android version (own + shared) | Automatic | No |
| Ring partner / find phone | Automatic if owner enabled it | No (alarm volume plays only while app can run; Android may limit background) |
| Foreground location | Automatic while sharing is on | Runtime permission once; revoked by OS anytime |
| Background location | Only if separately enabled | Separate OS prompt (Settings page on Android 11+) |
| Screen share | Preference only | **Every session**: owner approves in-app AND Android MediaProjection dialog; token never stored |
| Camera / mic / files / messages / call history | Not implemented, by design | n/a |

## Test checklist (two devices)
Pair, toggle each category off from owner side and confirm partner read fails, deny screen request,
approve then Stop, let timeout expire, unpair, delete account, reboot phones and confirm screen share does not auto-resume.

See BUILD.md for Gradle build, Firebase setup and the list of unimplemented features.
